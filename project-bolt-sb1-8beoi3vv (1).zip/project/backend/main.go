package main

import (
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "github.com/gorilla/mux"
)

type UnitPrice struct {
    Price         float64 `json:"price"`
    Measure       string  `json:"measure"`
    MeasureAmount int     `json:"measure_amount"`
}

type Product struct {
    ProductUID  string    `json:"product_uid"`
    ProductType string    `json:"product_type"`
    Name        string    `json:"name"`
    Image       string    `json:"image"`
    UnitPrice   UnitPrice `json:"unit_price"`
    IsAvailable bool      `json:"is_available"`
}

var products = map[string]Product{
    "6447344": {
        ProductUID:  "6447344",
        ProductType: "BASIC",
        Name:        "Sainsbury's Skin on ASC Scottish Salmon Fillets x2 240g",
        Image:       "https://assets.sainsburys-groceries.co.uk/gol/6447344/image.jpg",
        UnitPrice: UnitPrice{
            Price:         15.63,
            Measure:       "kg",
            MeasureAmount: 1,
        },
        IsAvailable: true,
    },
    "3052068": {
        ProductUID:  "3052068",
        ProductType: "BASIC",
        Name:        "Lurpak Slightly Salted Spreadable Blend of Butter & Rapeseed Oil 500g",
        Image:       "https://assets.sainsburys-groceries.co.uk/gol/3052068/image.jpg",
        UnitPrice: UnitPrice{
            Price:         7.5,
            Measure:       "kg",
            MeasureAmount: 1,
        },
        IsAvailable: true,
    },
}

func getProduct(w http.ResponseWriter, r *http.Request) {
    vars := mux.Vars(r)
    productUID := vars["product_uid"]

    product, exists := products[productUID]
    if !exists {
        w.WriteHeader(http.StatusNotFound)
        return
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(product)
}

func main() {
    router := mux.NewRouter()
    router.HandleFunc("/product/id/{product_uid}", getProduct).Methods("GET")

    fmt.Println("Server starting on :8080")
    log.Fatal(http.ListenAndServe("0.0.0.0:8080", router))
}