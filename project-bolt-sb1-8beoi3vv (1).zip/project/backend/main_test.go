package main

import (
    "encoding/json"
    "net/http"
    "net/http/httptest"
    "testing"
    "github.com/gorilla/mux"
)

func TestGetProduct(t *testing.T) {
    router := mux.NewRouter()
    router.HandleFunc("/product/id/{product_uid}", getProduct)

    testCases := []struct {
        name       string
        productUID string
        wantCode   int
    }{
        {"Valid product 6447344", "6447344", http.StatusOK},
        {"Valid product 3052068", "3052068", http.StatusOK},
        {"Invalid product", "999999", http.StatusNotFound},
    }

    for _, tc := range testCases {
        t.Run(tc.name, func(t *testing.T) {
            req, _ := http.NewRequest("GET", "/product/id/"+tc.productUID, nil)
            rr := httptest.NewRecorder()
            router.ServeHTTP(rr, req)

            if rr.Code != tc.wantCode {
                t.Errorf("got status %d, want %d", rr.Code, tc.wantCode)
            }

            if tc.wantCode == http.StatusOK {
                var product Product
                err := json.NewDecoder(rr.Body).Decode(&product)
                if err != nil {
                    t.Errorf("failed to decode response: %v", err)
                }
                if product.ProductUID != tc.productUID {
                    t.Errorf("got product %s, want %s", product.ProductUID, tc.productUID)
                }
            }
        })
    }
}