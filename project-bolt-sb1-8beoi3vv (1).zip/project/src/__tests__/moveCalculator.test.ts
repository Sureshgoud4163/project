import { describe, it, expect } from 'vitest';
import { calculateEndPosition } from '../moveCalculator';
import { parsePosition, formatPosition, wrapPosition } from '../utils/chessboard';

describe('Chess Position Calculator', () => {
  describe('calculateEndPosition', () => {
    it('should calculate correct end position for example 1', () => {
      expect(calculateEndPosition('2b', 3, 2)).toBe('5d');
    });

    it('should calculate correct end position for example 2', () => {
      expect(calculateEndPosition('5h', 11, 25)).toBe('8a');
    });
  });

  describe('parsePosition', () => {
    it('should correctly parse chess position', () => {
      expect(parsePosition('2b')).toEqual({ row: 1, col: 1 });
      expect(parsePosition('5h')).toEqual({ row: 4, col: 7 });
    });
  });

  describe('formatPosition', () => {
    it('should correctly format position numbers to chess notation', () => {
      expect(formatPosition(4, 3)).toBe('5d');
      expect(formatPosition(7, 0)).toBe('8a');
    });
  });

  describe('wrapPosition', () => {
    it('should correctly wrap positions within board bounds', () => {
      expect(wrapPosition(1, 3, 8)).toBe(4);
      expect(wrapPosition(7, 25, 8)).toBe(0);
    });
  });
});