import { describe, it, expect, vi } from 'vitest';
import { render, fireEvent, waitFor } from '@testing-library/react';
import axios from 'axios';
import App from '../App';

vi.mock('axios');

describe('Product Search App', () => {
  it('should disable search button when input is empty', () => {
    const { getByTestId } = render(<App />);
    const button = getByTestId('get-product-details');
    expect(button).toBeDisabled();
  });

  it('should enable search button when input has value', () => {
    const { getByTestId } = render(<App />);
    const input = getByTestId('product-uid');
    const button = getByTestId('get-product-details');

    fireEvent.change(input, { target: { value: '6447344' } });
    expect(button).toBeEnabled();
  });

  it('should display product details on successful API call', async () => {
    const mockProduct = {
      product_uid: '6447344',
      product_type: 'BASIC',
      name: 'Test Product',
      image: 'test.jpg',
      unit_price: {
        price: 15.63,
        measure: 'kg',
        measure_amount: 1
      },
      is_available: true
    };

    axios.get.mockResolvedValueOnce({ data: mockProduct });

    const { getByTestId } = render(<App />);
    const input = getByTestId('product-uid');
    const button = getByTestId('get-product-details');

    fireEvent.change(input, { target: { value: '6447344' } });
    fireEvent.click(button);

    await waitFor(() => {
      expect(getByTestId('name')).toHaveTextContent(mockProduct.name);
      expect(getByTestId('type')).toHaveTextContent(mockProduct.product_type);
      expect(getByTestId('price')).toHaveTextContent(mockProduct.unit_price.price.toString());
      expect(getByTestId('measure')).toHaveTextContent(mockProduct.unit_price.measure);
    });
  });

  it('should display "Not found" on API error', async () => {
    axios.get.mockRejectedValueOnce(new Error('404'));

    const { getByTestId, getByText } = render(<App />);
    const input = getByTestId('product-uid');
    const button = getByTestId('get-product-details');

    fireEvent.change(input, { target: { value: '999999' } });
    fireEvent.click(button);

    await waitFor(() => {
      expect(getByText('Not found')).toBeInTheDocument();
    });
  });
});