import { calculateEndPosition } from './moveCalculator';

// Example usage
const example1 = calculateEndPosition('2b', 3, 2);
console.log('Example 1:', example1); // Should output: 5d

const example2 = calculateEndPosition('5h', 11, 25);
console.log('Example 2:', example2); // Should output: 8a