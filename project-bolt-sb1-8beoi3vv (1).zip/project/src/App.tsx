import React, { useState } from 'react';
import axios from 'axios';

interface UnitPrice {
  price: number;
  measure: string;
  measure_amount: number;
}

interface Product {
  product_uid: string;
  product_type: string;
  name: string;
  image: string;
  unit_price: UnitPrice;
  is_available: boolean;
}

function App() {
  const [productUid, setProductUid] = useState('');
  const [product, setProduct] = useState<Product | null>(null);
  const [error, setError] = useState<string>('');

  const handleSearch = async () => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_BACKEND_APPLICATION_URL}/product/id/${productUid}`);
      setProduct(response.data);
      setError('');
    } catch (err) {
      setProduct(null);
      setError('Not found');
    }
  };

  return (
    <div className="container mx-auto p-4">
      <div className="mb-4">
        <input
          id="product-uid"
          type="text"
          value={productUid}
          onChange={(e) => setProductUid(e.target.value)}
          placeholder="Enter Product UID"
          className="border p-2 mr-2"
        />
        <button
          id="get-product-details"
          onClick={handleSearch}
          disabled={!productUid}
          className="bg-blue-500 text-white px-4 py-2 rounded disabled:opacity-50"
        >
          Search Product
        </button>
      </div>

      <div id="product" className="mt-4">
        {error ? (
          <div>{error}</div>
        ) : product ? (
          <div className="border p-4 rounded">
            <h2 id="name" className="text-xl font-bold mb-2">{product.name}</h2>
            <p id="type" className="mb-2">Type: {product.product_type}</p>
            <img id="image" src={product.image} alt={product.name} className="mb-2" />
            <p id="price" className="mb-1">Price: £{product.unit_price.price}</p>
            <p id="measure" className="mb-1">Measure: {product.unit_price.measure}</p>
          </div>
        ) : null}
      </div>
    </div>
  );
}

export default App;