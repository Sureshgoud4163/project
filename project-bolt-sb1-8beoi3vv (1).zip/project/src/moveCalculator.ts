import { BOARD_SIZE, parsePosition, formatPosition, wrapPosition } from './utils/chessboard';

export function calculateEndPosition(startPosition: string, R: number, C: number): string {
  // Parse the starting position
  const { row, col } = parsePosition(startPosition);

  // Calculate new row and column positions with wrapping
  const newRow = wrapPosition(row, R, BOARD_SIZE);
  const newCol = wrapPosition(col, C, BOARD_SIZE);

  // Format and return the final position
  return formatPosition(newRow, newCol);
}