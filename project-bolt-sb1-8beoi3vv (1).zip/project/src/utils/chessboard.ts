// Constants for the chessboard
export const BOARD_SIZE = 8;
export const COLUMNS = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

// Parse the position string into row and column numbers (0-based)
export function parsePosition(position: string): { row: number; col: number } {
  const row = parseInt(position[0]) - 1;
  const col = COLUMNS.indexOf(position[1].toLowerCase());
  return { row, col };
}

// Convert row and column numbers (0-based) to position string
export function formatPosition(row: number, col: number): string {
  return `${row + 1}${COLUMNS[col]}`;
}

// Calculate the new position after wrapping around the board
export function wrapPosition(position: number, moves: number, size: number): number {
  const totalMoves = (position + moves) % size;
  return totalMoves >= 0 ? totalMoves : size + totalMoves;
}